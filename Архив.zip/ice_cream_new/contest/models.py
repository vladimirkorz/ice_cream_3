from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator


class Contest(models.Model):
    title = models.CharField(
        "Название",
        max_length=20,
        blank=False,
        help_text="Обязательное!"
    )
    description = models.CharField(
        "Описание",
        blank=False,
        help_text="Обязательное!",
        max_length=255,
    )
    price = models.IntegerField(
        "Цена",
        blank=False,
        help_text="Рекомендованная розничная цена",
        validators=[
            MinValueValidator(10),
            MaxValueValidator(100),
        ]
    )
    comment = models.CharField(
        "Комментарий",
        blank=True,
        max_length=255,
    )