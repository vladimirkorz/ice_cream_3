from django.shortcuts import render

from contest.forms import ContestForm




def proposal(request):
    form = ContestForm(request.GET or None)

    context = {"form": form}

    if request.method == "GET" and form.is_valid():
        context["data"] = form.cleaned_data  # данные формы

    return render(request, 'contest/form.html', context)